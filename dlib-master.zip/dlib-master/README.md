# dlib
Hi Friends, there is all dlib wheel files for python version 7 to 11.. For more versions contact me!!!
Friends, Today i'm gona show you how to install dlib and face-recognition python library (pakages) without any errors just in 3 steps. Faild to build dlib OR Failed building wheel for dlib problems solved. Now you can easily install face recognition python library by watching this video. 
(***Search in Youtube: Murtaza i Tech***) (video link: https://youtu.be/cV4-uMobeM4?si=-kG7L7SjzgulNMKO)

This covers following topis:
Failed to build dlib | failed building wheel for dlib | face recognition installation error solved | pip install dlib error | pip install cmake error | pip install face-recognition error | dlib library install problem solved | face recognition python library install problem solved | How to install dlib | How to install face recognition library | how to install cmake library | error legacy install failure | not supported wheel for dlib

***You can also fix all type of Problems related to dlib***

Solutions: Just Follow these three Steps

Step-1
pip install cmake

Step-2 
pip install  dlib

***if any error try this***

Download the Files from here... Then Open command prompt (cmd) in the same folder where the file is located. Type in cmd...

pip install (copy file name and paste here) 

Step-3 
pip install face-recognition

***Note: the whl dlib files cp37 means CPython 3.7,  cp38 means CPython 3.8 and so on.***
